import json,sys
from collections import Counter,defaultdict
TPD=24
def load(p): return json.load(open(p))
def seat_of(rep,name):
    return rep['info']['TeamNames'].index(name)
def analyze(p,name='DECEM'):
    rep=load(p); s=seat_of(rep,name); o=1-s
    steps=rep['steps']
    sold=defaultdict(Counter); rev=defaultdict(float)
    buys=Counter(); spend=Counter()
    hires=Counter()
    for t in range(1,len(steps)):
        prev=steps[t-1][0]['observation']
        a=steps[t][s].get('action') or {}
        prices=prev['market']['prices']
        day=(t-1)//TPD
        for m in [m for m in (a.get('market') or []) if m]:
            if m[0]=='SELL':
                sold[m[1]][day//5]+=m[2]; rev[m[1]]+=m[2]*prices[m[1]]
            elif m[0]=='BUY_SEED': buys['seed:'+m[1]]+=m[2]
            elif m[0]=='BUY_ANIMAL': buys['animal:'+m[1]]+=m[2]
            elif m[0]=='BUY_PRODUCT': buys['prod:'+m[1]]+=m[2]
            elif m[0]=='HIRE': hires[day]+=1
            elif m[0]=='BUY_LAND': buys['land@%d'%(t-1)]+=1
    print('==',p, 'seat',s, rep['info']['TeamNames'], [x.get('reward') for x in steps[-1]])
    print(' shops', steps[-1][0]['observation']['town']['unlocked_shops'])
    for it in sorted(rev,key=lambda k:-rev[k]):
        print('  %-11s rev~%7.0f  sold by 5d blocks %s'%(it,rev[it],[sold[it][b] for b in range(6)]))
    print(' buys',dict(buys))
    print(' hires/day',[hires[d] for d in range(30)])
if __name__=='__main__':
    for p in sys.argv[1:]: analyze(p)
