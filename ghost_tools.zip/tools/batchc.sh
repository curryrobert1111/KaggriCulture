#!/bin/bash
tag=$1; shift
i=0
for v in "$@"; do i=$((i+1)); python variant.py var/${tag}_$i.py "$v"; r=$(./gh.sh var/${tag}_$i.py clean | tail -1); echo "$tag $v :: $r" >> res.txt; done
