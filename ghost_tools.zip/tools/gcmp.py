import sys, importlib.util
from collections import Counter
import ghost
rep=ghost.load_replay(sys.argv[1]); seat=int(sys.argv[3]); d0,d1=int(sys.argv[4]),int(sys.argv[5])
spec=importlib.util.spec_from_file_location("m",sys.argv[2]); M=importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
env=ghost.run_ghost(rep,M.agent,seat)
me=1-seat
for who,s in (('YOU',me),('TOP',seat)):
    c=Counter(); units=0
    for i in range(d0*24+1,d1*24+1):
        a=env.steps[i][s].action or {}
        us=[a.get('farmer')]+list(a.get('hands') or [])
        units+=len(us)
        for u in us:
            if u: c[u[0] if u[0] not in ('NORTH','SOUTH','EAST','WEST') else 'MOVE']+=1
    print(who,'unit-steps',units,{k:v for k,v in c.most_common()})
    f=env.steps[d1*24][0].observation['farms'][s]
    print('   money d%d'%d0, env.steps[d0*24][0].observation['farms'][s]['money'],'d%d'%d1,f['money'])
