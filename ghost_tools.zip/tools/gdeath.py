import sys, importlib.util
import ghost
rep=ghost.load_replay(sys.argv[1]); seat=int(sys.argv[3])
spec=importlib.util.spec_from_file_location("m",sys.argv[2]); M=importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
env=ghost.run_ghost(rep,M.agent,seat)
me=1-seat
n=0
for i in range(24,len(env.steps),24):
    A=env.steps[i-1][0].observation['farms'][me]['tiles']; B=env.steps[i][0].observation['farms'][me]['tiles']
    for y in range(10):
        for x in range(10):
            ta,tb=A[y][x],B[y][x]
            if isinstance(ta,dict) and ta.get('kind')=='PLANT' and isinstance(tb,dict) and tb.get('kind')=='WEED' and ta['consecutive_unwatered']>=1:
                d=(i-1)//24
                # count PASS actions this day and last-hours unit positions
                passes=0
                for j in range(d*24+1,d*24+24):
                    a=env.steps[j][me].action or {}
                    passes+=sum(1 for u in [a.get('farmer')]+list(a.get('hands') or []) if u and u[0]=='PASS')
                f=env.steps[d*24+20][0].observation['farms'][me]
                print('day',d,'died',ta['crop'],(x,y),'planted',ta['planted_day'],'passes',passes,'hands',len(f['hands']))
                n+=1
    if n>12: break
