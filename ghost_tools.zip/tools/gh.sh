#!/bin/bash
# usage: gh.sh agent.py [all|clean]
A=$1
L="115321748 0\n115324670 1\n115343521 0\n115350314 1\n115350323 1\n"
C="115321748 1\n115324670 0\n115343521 1\n115350314 0\n115350323 0\n"
if [ "$2" == "all" ]; then L="$L$C"; fi
if [ "$2" == "clean" ]; then L="$C"; fi
printf "$L" | xargs -P 2 -n 2 sh -c 'echo "$0 s$1 $(python ghost.py replays/$0.json '"$A"' --top $1 --summary 2>/dev/null | grep "you ")"' | awk '{print; you+=$5; top+=$7; n++; if($5>$7)w++} END {printf "GHOST %s: win %d/%d  mean you %.0f  mean top %.0f  gap %+.0f\n", "'"$A"'", w, n, you/n, top/n, (you-top)/n}'
