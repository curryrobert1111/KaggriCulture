import sys, importlib.util
from collections import Counter
import ghost
rep=ghost.load_replay(sys.argv[1]); seat=int(sys.argv[3])
spec=importlib.util.spec_from_file_location("m",sys.argv[2]); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
env=ghost.run_ghost(rep,mod.agent,seat)
me=1-seat
died=Counter(); decayed=Counter(); esc=Counter(); acts=Counter()
for i in range(1,len(env.steps)):
    a=env.steps[i][me].action or {}
    for u in [a.get('farmer')]+list(a.get('hands') or []):
        if u: acts[u[0] if u[0] not in ('NORTH','SOUTH','EAST','WEST') else 'MOVE']+=1
    A=env.steps[i-1][0].observation['farms'][me]['tiles']; B=env.steps[i][0].observation['farms'][me]['tiles']
    for y in range(10):
        for x in range(10):
            ta,tb=A[y][x],B[y][x]
            if isinstance(ta,dict) and ta.get('kind')=='PLANT' and isinstance(tb,dict) and tb.get('kind')=='WEED':
                if ta['consecutive_unwatered']>=1 and (i%24==0): died[ta['crop']]+=1
                else: decayed[ta['crop']]+=1
            if isinstance(ta,dict) and ta.get('animal') and isinstance(tb,dict) and not tb.get('animal'): esc[ta['animal']]+=1
print('died unwatered',dict(died)); print('decayed',dict(decayed)); print('escaped',dict(esc))
tot=sum(acts.values()); print('actions',tot,dict(acts.most_common()))
print('final',env.steps[-1][me].reward, env.steps[-1][seat].reward)
