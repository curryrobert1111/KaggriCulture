import sys, importlib.util
import ghost
rep=ghost.load_replay(sys.argv[1]); seat=int(sys.argv[3]); items=sys.argv[4].split(',')
spec=importlib.util.spec_from_file_location("m",sys.argv[2]); M=importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
env=ghost.run_ghost(rep,M.agent,seat)
for d in range(0,30):
    o=env.steps[d*24+12][0].observation
    print(d, o['town']['unlocked_shops'][-1:] , ' '.join(f"{it}:{o['market']['prices'][it]}/{o['market']['inventory'][it]-10000}" for it in items))
