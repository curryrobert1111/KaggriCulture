import sys, importlib.util
from collections import Counter
import ghost
rep=ghost.load_replay(sys.argv[1]); seat=int(sys.argv[3]); d0,d1=int(sys.argv[4]),int(sys.argv[5])
spec=importlib.util.spec_from_file_location("m",sys.argv[2]); M=importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
env=ghost.run_ghost(rep,M.agent,seat)
me=1-seat
for who,s in (('YOU',me),('TOP',seat)):
    rev=Counter(); n=Counter(); spend=Counter()
    for i in range(d0*24+1,d1*24+1):
        o0=env.steps[i-1][s].observation; o1=env.steps[i][s].observation
        sh0=o0['private']['shed']; sh1=o1['private']['shed']
        inv0=Counter(); inv1=Counter()
        for x in o0['private']['inventories']: inv0.update(x)
        for x in o1['private']['inventories']: inv1.update(x)
        a=env.steps[i][s].action or {}
        pr=env.steps[i-1][0].observation['market']['prices']
        for m in [m for m in (a.get('market') or []) if m and m[0]=='SELL']:
            it=m[1]
            # sold = shed0 + inflow(drops) - shed1 ; inflow = inv0 - inv1 (for this item, if positive and at end-of-day or drop)
            inflow=max(0,inv0[it]-inv1[it]) if (i%24)!=0 else 0
            k=max(0, sh0.get(it,0)+inflow-sh1.get(it,0))
            k=min(k,m[2]); rev[it]+=k*pr[it]; n[it]+=k
    print(who,'rev %.0f'%sum(rev.values()),' '.join(f"{it}:{n[it]}@{rev[it]/max(1,n[it]):.0f}" for it in sorted(n,key=lambda k:-rev[k])))
