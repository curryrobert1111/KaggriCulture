import sys, importlib.util
import ghost
rep=ghost.load_replay(sys.argv[1]); seat=int(sys.argv[3])
spec=importlib.util.spec_from_file_location("m",sys.argv[2]); M=importlib.util.module_from_spec(spec); spec.loader.exec_module(M)
env=ghost.run_ghost(rep,M.agent,seat)
me=1-seat
prev=None
for i in range(0,720,6):
    sh=env.steps[i][me].observation['private']['shed']
    n=(sh.get('SHEEP',0),sh.get('COW',0),sh.get('GOOSE',0))
    if n!=prev:
        f=env.steps[i][0].observation['farms'][me]
        es=sum(1 for row in f['tiles'] for t in row if isinstance(t,dict) and t.get('kind') in('PASTURE','COOP') and not t.get('animal'))
        print(i, i//24, 'shed S/C/G',n,'empty structs',es)
        prev=n
