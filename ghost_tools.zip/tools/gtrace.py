"""ghost-race one replay and print our per-day detail."""
import sys, json, importlib.util
from collections import Counter
import ghost
rep=ghost.load_replay(sys.argv[1]); seat=int(sys.argv[3])
spec=importlib.util.spec_from_file_location("m",sys.argv[2]); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
env=ghost.run_ghost(rep,mod.agent,seat)
me=1-seat
for d in range(30):
    i=min(719,d*24+12)
    o=env.steps[i][0].observation; f=o['farms'][me]
    c=Counter()
    for row in f['tiles']:
        for t in row:
            if t is None: c['.']+=1
            elif t=='LOCKED': pass
            elif t.get('kind')=='PLANT': c[t['crop'][:3]]+=1
            elif t.get('animal'): c[t['animal'][:3]]+=1
            else: c[t['kind'][:3]]+=1
    pr=o['market']['prices']
    print('d%2d $%6.0f h%2d q%d '%(d,f['money'],len(f['hands']),len(f['unlocked_quadrants'])), ' '.join(f'{a}{b}' for a,b in sorted(c.items())), '| STR%d MEL%d MIL%d WOO%d WHE%d'%(pr['STRAWBERRY'],pr['MELON'],pr['MILK'],pr['WOOL'],pr['WHEAT']))
print('final', env.steps[-1][me].reward, env.steps[-1][seat].reward)
