import argparse, importlib.util, os, sys, time
from multiprocessing import Pool
def load_agent(spec, tag):
    if spec.endswith(".py"):
        path = os.path.abspath(spec)
        m = importlib.util.spec_from_file_location(f"agent_{tag}_{abs(hash(path))}", path)
        mod = importlib.util.module_from_spec(m); m.loader.exec_module(mod); return mod.agent
    return spec
def play(args):
    a, b, seed, swap = args
    from kaggle_environments import make
    A = load_agent(a, "A"); B = load_agent(b, "B")
    env = make("kaggriculture", configuration={"seed": seed}, debug=True)
    t = time.time(); env.run([B, A] if swap else [A, B])
    r = [s.reward for s in env.steps[-1]]
    if swap: r = r[::-1]
    return seed, swap, r, time.time() - t
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("a"); ap.add_argument("b")
    ap.add_argument("-n", type=int, default=6); ap.add_argument("-j", type=int, default=2); ap.add_argument("--seed0", type=int, default=1000)
    ap.add_argument("-q", action="store_true")
    args = ap.parse_args()
    jobs = [(args.a, args.b, args.seed0 + i, sw) for i in range(args.n) for sw in (False, True)]
    w = l = t_ = 0; ra = []; rb = []
    with Pool(args.j) as pool:
        for seed, swap, r, dt in pool.imap_unordered(play, jobs):
            ra.append(r[0] or 0); rb.append(r[1] or 0)
            if ra[-1] > rb[-1]: w += 1
            elif ra[-1] < rb[-1]: l += 1
            else: t_ += 1
            if not args.q: print(f"seed {seed} swap={int(swap)} A={r[0]:>9} B={r[1]:>9} {dt:.1f}s", flush=True)
    n = len(ra)
    print(f"H2H {args.a} vs {args.b}: W/L/T = {w}/{l}/{t_}  mean A={sum(ra)/n:.0f}  mean B={sum(rb)/n:.0f}")
