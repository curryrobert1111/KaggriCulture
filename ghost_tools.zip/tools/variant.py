import json, sys
out, ov = sys.argv[1], json.loads(sys.argv[2])
base = sys.argv[3] if len(sys.argv) > 3 else "main.py"
src = open(base).read()
i = src.index("# Kaggle calls the LAST callable")
src = src[:i] + "PARAMS.update(%r)\n\n" % ov + src[i:]
open(out, "w").write(src)
